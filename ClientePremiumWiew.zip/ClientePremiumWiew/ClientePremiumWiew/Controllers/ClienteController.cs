using Microsoft.AspNetCore.Mvc;
using ClienteModel = ClientePremiumViewModel.Models.ClientePremiumViewModel;

namespace ClientePremiumViewModel.Controllers;

public class ClienteController : Controller
{
    // GET
    public IActionResult Cadastrar()
    {
        return View();
    }

    // POST
    [HttpPost]
    public IActionResult Cadastrar(ClienteModel cliente)
    {
        if (!ModelState.IsValid)
        {
            return View(cliente);
        }

        return Content("Cliente Premium cadastrado com sucesso!");
    }
}